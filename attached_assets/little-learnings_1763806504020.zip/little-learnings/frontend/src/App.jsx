import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import Header from "./components/Layouts/header.jsx";
import Footer from "./components/Layouts/footer.jsx";

import Homepage from "./Pages/Home/Homepage.jsx";
import AboutPage from "./Pages/About/AboutPage.jsx";
import AdmissionsPage from "./Pages/Admissions/AdmissionsPage.jsx";
import AcademicsPage from "./Pages/Academics/AcademicsPage.jsx";
import FacilitiesPage from "./Pages/Facilities/FacilitiesPage.jsx";
import GalleryPage from "./Pages/Gallery/GalleryPage.jsx";
import ContactPage from "./Pages/Contact/ContactPage.jsx";

export default function App() {
  return (
    <Router>
      <div className="min-h-screen flex flex-col bg-sky-50">
        <Header />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Homepage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/admissions" element={<AdmissionsPage />} />
            <Route path="/academics" element={<AcademicsPage />} />
            <Route path="/facilities" element={<FacilitiesPage />} />
            <Route path="/gallery" element={<GalleryPage />} />
            <Route path="/contact" element={<ContactPage />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}
