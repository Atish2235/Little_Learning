import React from "react";

function Footer() {
  return (
    <footer className="bg-sky-700 text-sky-50 mt-10">
      <div className="max-w-6xl mx-auto px-4 py-6 grid gap-4 sm:grid-cols-3 text-sm">
        <div>
          <h3 className="font-semibold text-base mb-2">Little Learnings School</h3>
          <p className="text-sky-100">
            A joyful place where little minds explore, create and grow every day.
          </p>
        </div>
        <div>
          <h3 className="font-semibold text-base mb-2">Contact</h3>
          <p>123 Rainbow Street, Pune</p>
          <p>Phone: +91-98765-43210</p>
          <p>Email: info@littlelearningschool.com</p>
        </div>
        <div>
          <h3 className="font-semibold text-base mb-2">School Timings</h3>
          <p>Mon – Fri: 8:30 AM – 2:30 PM</p>
          <p>Sat: 9:00 AM – 12:30 PM</p>
          <p>Sun: Closed</p>
        </div>
      </div>
      <div className="border-t border-sky-500/70 text-xs text-center py-2">
        © {new Date().getFullYear()} Little Learnings School. All rights reserved.
      </div>
    </footer>
  );
}

export default Footer;
