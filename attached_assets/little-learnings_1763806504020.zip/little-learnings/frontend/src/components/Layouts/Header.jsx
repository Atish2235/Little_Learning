import React from "react";
import { Link, NavLink } from "react-router-dom";

const navLinkClasses = ({ isActive }) =>
  `px-3 py-2 rounded-full text-sm font-medium transition
   ${isActive ? "bg-white text-sky-700 shadow-sm" : "text-white/90 hover:bg-sky-500/70"}`;

function Header() {
  return (
    <header className="bg-sky-600 shadow-md">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        {/* Logo / Brand */}
        <Link to="/" className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-full bg-yellow-300 flex items-center justify-center text-sky-800 font-extrabold text-lg">
            LL
          </div>
          <div className="leading-tight text-white">
            <div className="font-extrabold text-lg">Little Learnings School</div>
            <div className="text-xs text-white/80">Play • Learn • Grow</div>
          </div>
        </Link>

        {/* Nav links */}
        <nav className="hidden md:flex items-center gap-1">
          <NavLink to="/" className={navLinkClasses} end>Home</NavLink>
          <NavLink to="/about" className={navLinkClasses}>About</NavLink>
          <NavLink to="/admissions" className={navLinkClasses}>Admissions</NavLink>
          <NavLink to="/academics" className={navLinkClasses}>Academics</NavLink>
          <NavLink to="/facilities" className={navLinkClasses}>Facilities</NavLink>
          <NavLink to="/gallery" className={navLinkClasses}>Gallery</NavLink>
          <NavLink to="/contact" className={navLinkClasses}>Contact</NavLink>
        </nav>

        {/* Simple mobile button (you can improve later) */}
        <button className="md:hidden text-white text-sm border border-white/50 px-2 py-1 rounded-full">
          Menu
        </button>
      </div>
    </header>
  );
}

export default Header;
