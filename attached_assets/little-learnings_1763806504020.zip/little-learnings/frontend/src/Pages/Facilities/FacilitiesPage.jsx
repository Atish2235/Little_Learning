import React from "react";

export default function FacilitiesPage() {
  return (
    <div className="max-w-5xl mx-auto px-4 py-10">
      <h1 className="text-3xl font-bold text-sky-900 mb-4">Facilities</h1>
      <p className="text-gray-700">Information about facilities coming soon.</p>
    </div>
  );
}