import React from "react";

export default function AcademicsPage() {
  return (
    <div className="max-w-5xl mx-auto px-4 py-10">
      <h1 className="text-3xl font-bold text-sky-900 mb-4">Academics</h1>
      <p className="text-gray-700">Academic programs details will be added here.</p>
    </div>
  );
}