import React from "react";

export default function GalleryPage() {
  return (
    <div className="max-w-5xl mx-auto px-4 py-10">
      <h1 className="text-3xl font-bold text-sky-900 mb-4">Gallery</h1>
      <p className="text-gray-700">Photo gallery coming soon.</p>
    </div>
  );
}