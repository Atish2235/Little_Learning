// src/Pages/About/AboutPage.jsx
import React from "react";

export default function AboutPage() {
  return (
    <div className="max-w-5xl mx-auto px-4 py-10">
      <h1 className="text-3xl font-bold text-sky-900 mb-4">About Our School</h1>
      <p className="text-gray-700 text-sm md:text-base mb-4">
        Little Learnings School is a child-centred preschool committed to joyful
        learning. Our classrooms are colourful, welcoming and carefully designed
        for young children.
      </p>
      <p className="text-gray-700 text-sm md:text-base mb-4">
        We believe that children learn best through play, exploration and
        meaningful experiences. Our teachers work closely with each child,
        supporting their emotional, social and academic growth.
      </p>
      <ul className="list-disc list-inside text-gray-700 text-sm md:text-base">
        <li>Low student–teacher ratio</li>
        <li>Activity-based learning</li>
        <li>Regular parent–teacher communication</li>
        <li>Celebrations, field trips and events</li>
      </ul>
    </div>
  );
}
