import React from "react";

export default function AdmissionsPage() {
  return (
    <div className="max-w-5xl mx-auto px-4 py-10">
      <h1 className="text-3xl font-bold text-sky-900 mb-4">Admissions</h1>
      <p className="text-gray-700">Admissions information coming soon.</p>
    </div>
  );
}