import React from "react";
import { Link } from "react-router-dom";

export default function Homepage() {
  return (
    <div className="bg-sky-50">
      {/* Hero section */}
      <section className="bg-gradient-to-b from-sky-100 to-sky-50">
        <div className="max-w-6xl mx-auto px-4 py-14 md:py-20 grid md:grid-cols-2 gap-10 items-center">
          {/* Text */}
          <div>
            <p className="uppercase tracking-[0.2em] text-xs text-sky-700 font-semibold mb-3">
              Welcome to Little Learnings School
            </p>
            <h1 className="text-3xl md:text-5xl font-extrabold text-sky-900 mb-4 leading-tight">
              A happy place for{" "}
              <span className="text-amber-500">little explorers</span>.
            </h1>
            <p className="text-gray-700 text-sm md:text-base mb-6">
              We provide a safe, colourful and caring environment where children
              learn through play, stories, music and hands-on activities.
            </p>
            <div className="flex flex-wrap gap-3 mb-6">
              <Link
                to="/admissions"
                className="px-5 py-2.5 rounded-full bg-sky-600 text-white text-sm font-semibold shadow hover:bg-sky-700 transition"
              >
                Enquire for Admission
              </Link>
              <Link
                to="/contact"
                className="px-5 py-2.5 rounded-full border border-sky-500 text-sky-700 text-sm font-semibold hover:bg-white transition"
              >
                Visit Our Campus
              </Link>
            </div>
            {/* Small stats */}
            <div className="flex gap-6 text-xs md:text-sm text-sky-800">
              <div>
                <div className="font-extrabold text-lg md:text-xl">10+</div>
                <div>Years of nurturing kids</div>
              </div>
              <div>
                <div className="font-extrabold text-lg md:text-xl">20+</div>
                <div>Experienced teachers</div>
              </div>
              <div>
                <div className="font-extrabold text-lg md:text-xl">300+</div>
                <div>Happy students</div>
              </div>
            </div>
          </div>

          {/* Cute illustration block (no image yet, just design) */}
          <div className="flex justify-center">
            <div className="w-full max-w-sm bg-white rounded-3xl shadow-lg p-5 relative overflow-hidden">
              <div className="absolute -top-6 -left-6 w-16 h-16 bg-amber-300 rounded-full opacity-70" />
              <div className="absolute -bottom-8 -right-8 w-24 h-24 bg-sky-200 rounded-full opacity-70" />
              <div className="relative">
                <h2 className="text-xl font-bold text-sky-900 mb-2">
                  Today&apos;s Little Moments
                </h2>
                <p className="text-gray-700 text-sm mb-4">
                  Story time, fun games, colourful art and lots of smiles! Every
                  day is a new adventure.
                </p>
                <ul className="space-y-2 text-sm">
                  <li>🌈 Colourful classrooms</li>
                  <li>📚 Phonics & early reading</li>
                  <li>🎨 Art & craft activities</li>
                  <li>⚽ Outdoor play & games</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why parents choose us */}
      <section className="max-w-6xl mx-auto px-4 py-12">
        <h2 className="text-2xl md:text-3xl font-bold text-sky-900 text-center mb-8">
          Why Parents Choose Little Learnings
        </h2>
        <div className="grid sm:grid-cols-3 gap-6 text-sm">
          <div className="bg-white rounded-2xl shadow p-5">
            <div className="text-2xl mb-2">👩‍🏫</div>
            <h3 className="font-semibold mb-1">Caring Teachers</h3>
            <p className="text-gray-700">
              Qualified, friendly and patient teachers who guide every child with
              love and attention.
            </p>
          </div>
          <div className="bg-white rounded-2xl shadow p-5">
            <div className="text-2xl mb-2">🧸</div>
            <h3 className="font-semibold mb-1">Safe Environment</h3>
            <p className="text-gray-700">
              CCTV, child-safe furniture and clean classrooms designed for little
              learners.
            </p>
          </div>
          <div className="bg-white rounded-2xl shadow p-5">
            <div className="text-2xl mb-2">📅</div>
            <h3 className="font-semibold mb-1">Play-based Learning</h3>
            <p className="text-gray-700">
              Activities that build confidence, language skills and creativity
              through play.
            </p>
          </div>
        </div>
      </section>

      {/* Programs overview */}
      <section className="bg-white border-t border-sky-100">
        <div className="max-w-6xl mx-auto px-4 py-12">
          <h2 className="text-2xl md:text-3xl font-bold text-sky-900 text-center mb-8">
            Our Programs
          </h2>
          <div className="grid md:grid-cols-3 gap-6 text-sm">
            <div className="bg-sky-50 rounded-2xl p-5 border border-sky-100">
              <h3 className="font-semibold mb-1">Playgroup (2–3 years)</h3>
              <p className="text-gray-700">
                Gentle introduction to school with songs, stories and sensory play.
              </p>
            </div>
            <div className="bg-sky-50 rounded-2xl p-5 border border-sky-100">
              <h3 className="font-semibold mb-1">Nursery (3–4 years)</h3>
              <p className="text-gray-700">
                Early concepts of numbers, shapes, colours and language building.
              </p>
            </div>
            <div className="bg-sky-50 rounded-2xl p-5 border border-sky-100">
              <h3 className="font-semibold mb-1">Jr & Sr KG (4–6 years)</h3>
              <p className="text-gray-700">
                Strong foundation in reading, writing and math skills for primary
                school.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
